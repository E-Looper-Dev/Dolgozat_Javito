﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace MemoryGame
{
    /// <summary>
    /// Interaction logic for Game.xaml
    /// </summary>
    public partial class Game : Window
    {
        public List<Button> buttons = new List<Button>();
        public List<int> szamok = new List<int>();
        private DateTime startTime;
        public Game(int number)
        {
            InitializeComponent();
            SzamGeneralas(number);
            GridBeallitas(number);
            startTime = DateTime.Now;
        }
        public int mentett_szam = 0;
        public void GridBeallitas(int szam)
        {
            for (int i = 0; i < szam; i++)
            {
                Racs.RowDefinitions.Add(new RowDefinition());
            }
            for (int i = 0; i < szam; i++)
            {
                Racs.ColumnDefinitions.Add(new ColumnDefinition());
            }
            Gombok(szam);
        }
        private bool parokMegtalalva()
        {
            foreach (Button button in buttons)
            {
                if (button.Content == null)
                {
                    return false;
                }
            }
            return true;
        }

        public void Gombok(int szam)
        {
            mentett_szam = szam;
            Random r = new Random();
            int n = szamok.Count;
            while (n > 1)
            {
                n--;
                int k = r.Next(n + 1);
                int value = szamok[k];
                szamok[k] = szamok[n];
                szamok[n] = value;
            }
            for (int sor = 0; sor < szam; sor++)
            {
                for (int oszlop = 0; oszlop < szam; oszlop++)
                {
                    Button button = new Button();
                    button.FontSize = 30;
                    button.Content = null;
                    Grid.SetRow(button, sor);
                    Grid.SetColumn(button, oszlop);
                    Racs.Children.Add(button);
                    buttons.Add(button);
                    button.Click += Button_Click;
                }
            }
        }
        public void SzamGeneralas(int szam)
        {
            for (int i = 1; i <= szam * szam / 2; i++)
            {
                szamok.Add(i);
                szamok.Add(i);
            }
        }
        private Button elsoButton = null;
        int elsoIndex = 0;
        private async void Button_Click(object sender, RoutedEventArgs e)
        {
            Button clickedButton = sender as Button;
            int index = buttons.IndexOf(clickedButton);
            clickedButton.Content = szamok[index];
            if (parokMegtalalva())
            {
                TimeSpan elapsedTime = DateTime.Now - startTime;
                MessageBox.Show($"Gratulálok! Összesen {elapsedTime.TotalSeconds} másodperc alatt találtad meg az összes párt!");
                this.Close();
            }
            if (elsoButton == null)
            {
                elsoButton = clickedButton;
                elsoIndex = index;
            }
            else
            {
                Button secondButton = clickedButton;
                if (szamok[elsoIndex] == szamok[index])
                {
                    elsoButton = null;
                }
                else
                {
                    CheckButtons(elsoButton, secondButton);
                    elsoButton = null;
                }
            }
        }
        private async void CheckButtons(Button firstButton, Button secondButton)
        {
            if (firstButton.Content.ToString() == secondButton.Content.ToString() && buttons.IndexOf(firstButton) != buttons.IndexOf(secondButton))
            {
                return;
            }
            else
            {
                await Task.Delay(1000);
                firstButton.Content = secondButton.Content = "";
            }
        }
    }
}
